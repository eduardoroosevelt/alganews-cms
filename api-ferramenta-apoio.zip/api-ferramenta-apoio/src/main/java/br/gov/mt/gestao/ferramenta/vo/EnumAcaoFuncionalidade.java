package br.gov.mt.gestao.ferramenta.vo;

public enum EnumAcaoFuncionalidade {

	INCLUIR("Incluir"),
	ALTERAR("Alterar"),
	EXCLUIR("Excluir"),
	CONSULTAR("Consultar");
	
	private String descricao;
	
	EnumAcaoFuncionalidade(String descricao) {
		this.descricao = descricao;
	}
	
	public String getDescricao() {
		return descricao;
	}
}
