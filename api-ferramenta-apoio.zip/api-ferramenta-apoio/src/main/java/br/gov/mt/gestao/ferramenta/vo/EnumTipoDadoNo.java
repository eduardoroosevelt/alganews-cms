package br.gov.mt.gestao.ferramenta.vo;

public enum EnumTipoDadoNo {
	
	CLASSE("Classe"),
	PROPRIEDADE("Propriedade");
	
	private String descricao;
	
	private EnumTipoDadoNo(String descricao) {
		this.descricao = descricao;
	}
	
	public String getDescricao() {
		return descricao;
	}
}
