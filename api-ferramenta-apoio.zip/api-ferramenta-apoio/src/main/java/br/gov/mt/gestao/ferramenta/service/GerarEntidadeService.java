package br.gov.mt.gestao.ferramenta.service;

import java.io.IOException;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.gov.mt.gestao.ferramenta.service.geracao.ClasseRepository;
import br.gov.mt.gestao.ferramenta.service.geracao.GeracaoResource;
import br.gov.mt.gestao.ferramenta.service.geracao.GerarEntidade;
import br.gov.mt.gestao.ferramenta.service.geracao.GerarService;
import br.gov.mt.gestao.ferramenta.service.geracao.GerarTelas;
import br.gov.mt.gestao.ferramenta.vo.Arvore;
import br.gov.mt.gestao.ferramenta.vo.Entidade;
import br.gov.mt.gestao.ferramenta.vo.NoArvore;
import br.gov.mt.gestao.ferramenta.vo.ProjetoGerador;
import br.gov.mt.gestao.ferramenta.vo.Propriedade;
import br.gov.mt.gestao.thanos.util.ArquivoUtil;
import br.gov.mt.gestao.thanos.util.TextoUtil;

@Service
public class GerarEntidadeService {

	private String nomeSchema = "RECADASTRO";
	
	@Autowired
	private DataSource dataSource;
	
	@Autowired
	private GerarEntidade gerarEntidade; 
	
	public List<String> listarTabelas() throws Exception {
		
		/***
		 * Tipos de dados do JPA: 
		 * java.sql.Types 
		 * 
		 */
		
		// Cria a variavel de retorno
		List<String> listaTab = new ArrayList<>();
		// Carrega o metadata (estrutura) do banco de dados
		DatabaseMetaData metaData = dataSource.getConnection().getMetaData();
		// Carrega somente as tabelas do banco de dados
		ResultSet tabelas = metaData.getTables(null, null, null, new String[] {"TABLE", "VIEW"});
		
		// Percorre o retorno dos dados do banco
		while (tabelas.next()) {
			// Carrega o nome da tabela
			String tableName = tabelas.getString("TABLE_NAME");
			String origem = tabelas.getString("TABLE_SCHEM");
			
			//if (!origem.equals("RECADASTRO")) {
			if (!origem.equals(nomeSchema)) {			
				continue;
			}
			
			//ResultSetMetaData rsmd = tabelas.getMetaData();
			//int numCols = rsmd.getColumnCount();
            listaTab.add("Tabela: " + tableName + " - Origem: " + origem);
            
            
            // Lista as chaves primarias da tabela
            ResultSet pk = metaData.getPrimaryKeys(null,null, tableName);
            while(pk.next())
            {
            	listaTab.add("Chave Primária: " + pk.getString("COLUMN_NAME"));
            }
            pk.close();

            listaTab.add("");
            // Carrega as chaves primárias da tabela
            ResultSet fk =  metaData.getImportedKeys(null, null, tableName);
            while(fk.next()) {
            	listaTab.add("ForeginKey -> Tabela Origem:" + fk.getString("PKTABLE_NAME") + 
            			" Coluna Origem: " + fk.getString("PKCOLUMN_NAME") +
            			" Tabela Destino: " + fk.getString("FKTABLE_NAME") +
            			" Coluna Destino: " + fk.getString("FKCOLUMN_NAME"));
            }
            listaTab.add("");
            fk.close();
            
            // Carrega os campos da tabela
            ResultSet columns = metaData.getColumns(null,  null,  tableName, "%");
            while (columns.next()) {
            	listaTab.add("Coluna: " + columns.getString("COLUMN_NAME") + 
            			     " - TYPE_NAME: " + columns.getString("TYPE_NAME") +
            			     " - DATA_TYPE: " + columns.getString("DATA_TYPE") +
            			     " - Tamanho: " + columns.getString("COLUMN_SIZE") + 
            			     " - NULLABLE: " + columns.getString("NULLABLE") +
            			     " - IS_AUTOINCREMENT: " + columns.getString("IS_AUTOINCREMENT")+ 
            			     " - DECIMAL_DIGITS: " + columns.getString("DECIMAL_DIGITS"));
            }
            listaTab.add("--------------------------------------------------------------");
            columns.close();
//            cont++;
//            if (cont > 40) {
//            	break;
//            }
        } 
		tabelas.close();

		// envia o retorno da consulta
		return listaTab;
	}
	
	public String gerarCodigoTabela(String pathArquivos, String pathPacote) throws Exception {
		// Cria as pastas model e repository
		ArquivoUtil.criarDiretorio(pathArquivos + "/model");
		ArquivoUtil.criarDiretorio(pathArquivos + "/repository");
		ArquivoUtil.criarDiretorio(pathArquivos + "/resource");
		ArquivoUtil.criarDiretorio(pathArquivos + "/service");
		// Carrega o metadata (estrutura) do banco de dados
		DatabaseMetaData metaData = dataSource.getConnection().getMetaData();
		// Carrega somente as tabelas do banco de dados
		ResultSet tabelas = metaData.getTables(null, null, null, new String[] {"TABLE"});
		// Percorre o retorno dos dados do banco
		while (tabelas.next()) {
			// Cria a o objeto entidade
			Entidade entidade = new Entidade();
			ClasseRepository rep = new ClasseRepository();
			GeracaoResource resource = new GeracaoResource();
			GerarService service = new GerarService();
			
			 // Carrega o nome da tabela
			String tableName = tabelas.getString("TABLE_NAME");
            entidade.setNomeTabela(tableName);
            entidade.setPacoteCompleto(pathPacote);

            String origem = tabelas.getString("TABLE_SCHEM");
			
			if (!origem.equals(nomeSchema)) {
				continue;
			}
            
            // campo_chave
            String campoChave = "";
            // Lista as chaves primarias da tabela
            ResultSet pk = metaData.getPrimaryKeys(null,null, tableName);
            while(pk.next())
            {
            	campoChave = pk.getString("COLUMN_NAME");
            }
            pk.close();
            
            // Carrega os campos da tabela
            ResultSet columns = metaData.getColumns(null,  null,  tableName, "%");
            while (columns.next()) {
            	// Carrega os dados do campo na propriedade
            	Propriedade prop = new Propriedade();
            	prop.setNomeCampo(columns.getString("COLUMN_NAME"));
            	prop.setTipoDado(columns.getInt("DATA_TYPE"));
            	prop.setNomeTipodado(columns.getString("TYPE_NAME"));
            	prop.setTamanho(columns.getInt("COLUMN_SIZE"));
            	prop.setDecimals(columns.getInt("DECIMAL_DIGITS"));
            	prop.setCampoNulo(columns.getBoolean("NULLABLE"));
            	prop.setAutoIncremento(columns.getBoolean("IS_AUTOINCREMENT"));
            	prop.setChavePrimaria(prop.getNomeCampo().equals(campoChave));
            	// Adiciona a propriedade na Entidade
            	entidade.setPropriedade(prop);
            }
            columns.close();
            
            // Recebe o codigo fonte classe model
            String codigoFonte = gerarEntidade.gerarCodigoEntidade(entidade);
            
            // Se a entidade não possui campo chave não gera o código fonte dela, pois a tabela é relacionamento 
            if (!entidade.isGerarCodigo() || entidade.getChavePrimaria() == null) {
            	continue;
            }
            
    		// gera o arquivo .java das classes models
    		ArquivoUtil.gerarArquivoJava(codigoFonte, entidade.getNomeClasse()  + ".java", pathArquivos + "/model");
    		
    		// Gera o código fonte repository
    		codigoFonte = rep.gerarCodigoRepository(entidade);
    		
    		// gera o arquivo .java das classes repository
    		ArquivoUtil.gerarArquivoJava(codigoFonte, entidade.getNomeClasse() + "Repository"  + 
    		          ".java", pathArquivos + "/repository");
    		
    		// Gera o código fonte do service
    		codigoFonte = service.gerarCodigo(entidade);
    		
    		// gera o arquivo .java das classes service
    		ArquivoUtil.gerarArquivoJava(codigoFonte, entidade.getNomeClasse() + "Service"  + 
    		          ".java", pathArquivos + "/service");
    		
    		// Gera o código fonte do resource
    		codigoFonte = resource.gerarCodigo(entidade);
    		
    		// gera o arquivo .java das classes resource
    		ArquivoUtil.gerarArquivoJava(codigoFonte, entidade.getNomeClasse() + "Resource"  + 
    		          ".java", pathArquivos + "/resource");
        } 
		tabelas.close();
		// Gera o código da classe entidade
		return "Código gerado com sucesso."; //codigoFonte;
	}
	
	public Arvore carregarEntidadesBanco(ProjetoGerador projeto) throws SQLException{
		try {
			// Carrega o metadata (estrutura) do banco de dados
			DatabaseMetaData metaData = dataSource.getConnection().getMetaData();
			// Carrega o nome do Schema informado
			if (projeto.getNomeSchema() != null || !projeto.getNomeSchema().isEmpty()) {
				nomeSchema = projeto.getNomeSchema();
			}
			// Carrega somente as tabelas do banco de dados
			ResultSet tabelas = metaData.getTables(null, null, null, new String[] {"TABLE", "VIEW"});
			
			// Percorre o retorno dos dados do banco
			while (tabelas.next()) {
				// Cria a o objeto entidade
				Entidade entidade = new Entidade();
				
				 // Carrega o nome da tabela
				String tableName = tabelas.getString("TABLE_NAME");

				String origem = tabelas.getString("TABLE_SCHEM");
				
//				if (!origem.equals("INSCRICAO") && !origem.equals("DOMINIO") && 
//					!origem.equals("SEGURANCA") && !origem.equals("GERAL")) {
//					continue;
//				}
				
				if (!origem.equals(nomeSchema)) {
					continue;
				}
				
	            entidade.setNomeTabela(tableName);
	            entidade.setNomeSchema(origem);
	            entidade.setPacoteCompleto(projeto.getPacoteCompleto());
	            
	            // Se a tabela for menor que o tamanho do prefixo mais dois ignora a tabela
	            if (tableName.length() < (2 + projeto.getTamamhoPrefixo()) || tableName.contains("$") ||
	            	(tableName.length() >= 8 &&	tableName.substring(6, 7).equals("_"))) {
	            	continue;
	            }
	            
	    		// Formata o nome da classe no padrão Java
	    		entidade.setNomeClasse(TextoUtil.iniMaiuscula(tableName.toLowerCase().substring(projeto.getTamamhoPrefixo()), "_", true));
				
	            // campo_chave
	            String campoChave = "";
	            // Lista as chaves primarias da tabela
	            ResultSet pk = metaData.getPrimaryKeys(null,null, tableName);
	            while(pk.next())
	            {
	            	campoChave = pk.getString("COLUMN_NAME");
	            }
	            pk.close();
	            
	            // Carrega os campos da tabela
	            ResultSet columns = metaData.getColumns(null,  null,  tableName, "%");
	            
	            // Precorre os campos
	            while (columns.next()) {
	            	// Se o campo chave não encontrou e informou que deve ignorar a chave primaria pega o primeiro campo da lista
	                if (campoChave.equals("") && projeto.isIgnorarChavePrimaria()) {
	                	campoChave = columns.getString("COLUMN_NAME");
	                }
	            	// Carrega os dados do campo na propriedade
	            	Propriedade prop = new Propriedade();
	            	prop.setNomeCampo(columns.getString("COLUMN_NAME"));
	            	prop.setTipoDado(columns.getInt("DATA_TYPE"));
	            	prop.setNomeTipodado(columns.getString("TYPE_NAME"));
	            	prop.setTamanho(columns.getInt("COLUMN_SIZE"));
	            	prop.setDecimals(columns.getInt("DECIMAL_DIGITS"));
	            	prop.setCampoNulo(columns.getBoolean("NULLABLE"));

	            	if(columns.getString("IS_AUTOINCREMENT").equals("NO")) {
	            		prop.setAutoIncremento(false);
	            	}
	            	else {
	            		prop.setAutoIncremento(columns.getBoolean("IS_AUTOINCREMENT"));
	            	}
	            	prop.setChavePrimaria(prop.getNomeCampo().equals(campoChave));
	            	prop.setColunaGridCss(getTamanhoCampo(prop));
	            	// Adiciona a propriedade na Entidade
	            	entidade.setPropriedade(prop);
	            }
	            columns.close();

	            // Se a entidade não possiui campos ignora-a
	            if (entidade.getPropriedades().size() <= 0 ) {
	            	continue;
	            }
	            
	            // Carrega as informações da entidade
	            gerarEntidade.gerarCodigoEntidade(entidade);
	            
	            // Se a entidade não possui campo chave não gera o código fonte dela, pois a tabela é relacionamento 
	            if (entidade.getChavePrimaria() == null  && !projeto.isIgnorarChavePrimaria()) {
	            	continue;
	            }
	            
	            // adiciona a entidade na lista de entidades mapeadas
	            projeto.getEntidades().add(entidade);
	        }
			tabelas.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		// Preenche a arvore a ser exibida para o usuário
		Arvore arvore = gerarArvoreProjeto(projeto);
		
		// Retorna as entidades mapeadas do banco de dados
		return arvore;
	}
	
	private String getTamanhoCampo(Propriedade prop) {
		// Verifica o tamanho do campo
		if (prop.getTamanho() <= 6) {
			return "6 4 2";
		}
		else if (prop.getTamanho() <= 15) {
			return "12 6";
		}
		else {
			return "12";
		}
	}
	
	private Arvore gerarArvoreProjeto(ProjetoGerador projeto) {
		Arvore arvore = new Arvore();
		NoArvore no, noProp = null;
		Entidade entidade = null;
		Propriedade prop = null;
		
		// Carrega a instancia do projeto
		arvore.setProjeto(projeto);
		
		// Carrega os das entidades na arvore
		for (int i = 0; i < projeto.getEntidades().size(); i++) {
			// Carrega a instancia da entidade e cria um novo nó na arvore
			entidade = projeto.getEntidades().get(i);
			no = new NoArvore();
			
			// Carrega os dados da entidade no nó
			no.setKey(Integer.toString(i));
			no.setData(entidade);
			
			// Carrega os campos da entidade na arvore
			for (int j = 0; j < entidade.getPropriedades().size(); j++) {
				// Carrega a instacnia da propriedade e instancia o no da arvore
				prop = entidade.getPropriedades().get(j);
				noProp = new NoArvore();
				
				// Carrega os dados do No da arvore
				noProp.setKey(Integer.toString(i) + "-" + Integer.toString(j));
				noProp.setData(prop);
				
				// adiciona o no propriedade ao no pai
				no.getChildren().add(noProp);
			}
			// Adiciona a o no a arvore
			arvore.getRoot().add(no);
		}
		
		// Retorna a arvore gerada
		return arvore;
	}
	
	public String gerarCodigosClasses(ProjetoGerador projeto) throws IOException {
		
		// Carrega a path do local onde será salvo os arquivos gerados
		String pathArquivos = projeto.getPathArquivosSaida();
		// Cria as pastas model e repository
		ArquivoUtil.criarDiretorio(pathArquivos + "/model");
		ArquivoUtil.criarDiretorio(pathArquivos + "/repository");
		ArquivoUtil.criarDiretorio(pathArquivos + "/resource");
		ArquivoUtil.criarDiretorio(pathArquivos + "/service");
		ArquivoUtil.criarDiretorio(pathArquivos + "/vue");
		
		// Percorre as entidades do projeto
		for (Iterator<Entidade> iterator = projeto.getEntidades().iterator(); iterator.hasNext();) {
			// Carrega a entidade do projeto
			Entidade entidade = iterator.next();

			// Cria as instancias das outras camadas
			ClasseRepository rep = new ClasseRepository();
			GeracaoResource resource = new GeracaoResource();
			GerarService service = new GerarService();
			GerarTelas telas = new GerarTelas();
			
			// Recebe o codigo fonte classe model
	        String codigoFonte = gerarEntidade.gerarCodigoEntidade(entidade);
	        
	        // Se a entidade não possui campo chave não gera o código fonte dela, pois a tabela é relacionamento 
	        if (entidade.getChavePrimaria() == null && !projeto.isIgnorarChavePrimaria()) {
	        	continue;
	        }
	        
			// gera o arquivo .java das classes models
			ArquivoUtil.gerarArquivoJava(codigoFonte, entidade.getNomeClasse()  + ".java", pathArquivos + "/model");
			
			// Gera o código fonte repository
			codigoFonte = rep.gerarCodigoRepository(entidade);
			
			// gera o arquivo .java das classes repository
			ArquivoUtil.gerarArquivoJava(codigoFonte, entidade.getNomeClasse() + "Repository"  + 
			          ".java", pathArquivos + "/repository");
			
			// Gera o código fonte do service
			codigoFonte = service.gerarCodigo(entidade);
			
			// gera o arquivo .java das classes service
			ArquivoUtil.gerarArquivoJava(codigoFonte, entidade.getNomeClasse() + "Service"  + 
			          ".java", pathArquivos + "/service");
			
			// Gera o código fonte do resource
			codigoFonte = resource.gerarCodigo(entidade);
			
			// gera o arquivo .java das classes resource
			ArquivoUtil.gerarArquivoJava(codigoFonte, entidade.getNomeClasse() + "Resource"  + 
			          ".java", pathArquivos + "/resource");
			
			// Gera o código fonte do resource
			codigoFonte = telas.gerarCodigoTela(entidade);
			
			// gera o arquivo .java das classes resource
			ArquivoUtil.gerarArquivoJava(codigoFonte,"Cad" + entidade.getNomeClasse() + 
			          ".vue", pathArquivos + "/vue");
		}
		// Gera o código da classe entidade
		return "Código gerado com sucesso."; //codigoFonte;
	}	
}
