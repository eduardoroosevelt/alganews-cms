package br.gov.mt.gestao.ferramenta.vo;

public class ChaveEstrangeira {

	private String nomeTabelaOrigem;
	private String nomeTabelaDestino;
	private String nomeCampoOrigem;
	private String nomeCampoDestino;
	private Entidade tabelaOrigem;
	private Entidade tabelaDestino;

	public String getNomeTabelaOrigem() {
		return nomeTabelaOrigem;
	}

	public void setNomeTabelaOrigem(String nomeTabelaOrigem) {
		this.nomeTabelaOrigem = nomeTabelaOrigem;
	}

	public String getNomeTabelaDestino() {
		return nomeTabelaDestino;
	}

	public void setNomeTabelaDestino(String nomeTabelaDestino) {
		this.nomeTabelaDestino = nomeTabelaDestino;
	}

	public String getNomeCampoOrigem() {
		return nomeCampoOrigem;
	}

	public void setNomeCampoOrigem(String nomeCampoOrigem) {
		this.nomeCampoOrigem = nomeCampoOrigem;
	}

	public String getNomeCampoDestino() {
		return nomeCampoDestino;
	}

	public void setNomeCampoDestino(String nomeCampoDestino) {
		this.nomeCampoDestino = nomeCampoDestino;
	}

	public Entidade getTabelaOrigem() {
		return tabelaOrigem;
	}

	public void setTabelaOrigem(Entidade tabelaOrigem) {
		this.tabelaOrigem = tabelaOrigem;
	}

	public Entidade getTabelaDestino() {
		return tabelaDestino;
	}

	public void setTabelaDestino(Entidade tabelaDestino) {
		this.tabelaDestino = tabelaDestino;
	}

	@Override
	public String toString() {
		return "ChaveEstrangeira [nomeTabelaOrigem=" + nomeTabelaOrigem + ", nomeTabelaDestino=" + nomeTabelaDestino
				+ ", nomeCampoOrigem=" + nomeCampoOrigem + ", nomeCampoDestino=" + nomeCampoDestino + ", tabelaOrigem="
				+ tabelaOrigem + ", tabelaDestino=" + tabelaDestino + "]";
	}

}
