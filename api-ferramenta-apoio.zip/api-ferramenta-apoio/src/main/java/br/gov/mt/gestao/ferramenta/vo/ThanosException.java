package br.gov.mt.gestao.ferramenta.vo;

public class ThanosException extends RuntimeException{

	private static final long serialVersionUID = -409889946864421783L;

	public ThanosException(String message, Throwable cause) {
		super(message, cause);
	}

	public ThanosException(String message) {
		super(message);
	}
	
}
