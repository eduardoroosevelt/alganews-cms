package br.gov.mt.gestao.ferramenta.service.geracao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.gov.mt.gestao.ferramenta.vo.Entidade;
import br.gov.mt.gestao.ferramenta.vo.Propriedade;

@Component
public class GerarTelas {
	
	public static final String TABULACAO = "\t";
	
	public String gerarCodigoTela(Entidade entidade) {
		String codigoFonte = "";

		// Gerar a template HTML do código da Tela 
		codigoFonte += gerarTemplate(entidade);
		
		// Gerar o script do Vue
		codigoFonte += gerarScriptStyle(entidade);
		
		return codigoFonte;
	}
	
	private String gerarTemplate(Entidade entidade) {
		// Cria a lista para armazenar o código em linhas
		List<String> codigo = new ArrayList<String>();
		
		codigo.add("<template>");
		codigo.add(TABULACAO + "<div class=\"p-grid p-fluid\">");
		codigo.add(TABULACAO + TABULACAO + "<card-seplag titulo=\""+ getNomeCadastro(entidade) +"\" cor=\"#00acc1\" >");
		codigo.add("");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "<table-seplag :dados=\"dadosTabela\" :paginacao=\"true\" :campos=\"colunasTabela\"");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + ":onAdicionarDado=\"incluirRegistro\" :onEditarDado=\"editarRegistro\" :onExcluirDado=\"excluirRegistro\">");
		codigo.add("");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "</table-seplag>");
		codigo.add("");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "<cadastro-rapido tituloTela=\""+ getNomeCadastro(entidade) +"\" v-model=\"exibirTela\" :modoEdicao=\"modoEdicao\"");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + ":onAdicionar=\"adicionarRegistro\" :onAlterar=\"alterarRegistro\" v-if=\"registro\" >");
		
		// Adiciona os campos no cadastro rapido
		adicionarCamposCadastro(entidade, codigo);
		
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "</cadastro-rapido>");
		codigo.add("");
		codigo.add(TABULACAO + TABULACAO + "</card-seplag>");
		codigo.add(TABULACAO + "</div>");
		codigo.add("</template>");
		codigo.add("");
		
		// Retorna o código gerado
		return StringUtils.arrayToDelimitedString(codigo.toArray(), "\n");
	}
	
	private String getNomeCadastro(Entidade entidade) {
		// se não informou o nome da Tela pega o nome da classe
		if (entidade.getNomeTela() == null || entidade.getNomeTela().isEmpty()) {
			return entidade.getNomeClasse();
		}
		else {
			return entidade.getNomeTela();
		}
	}
	
	private void adicionarCamposCadastro(Entidade entidade, List<String> codigo) {
		codigo.add("");
		// Percorre os campos da entidade
		for (Iterator<Propriedade> iterator = entidade.getPropriedades().iterator(); iterator.hasNext();) {
			// Carrega a propriedade
			Propriedade prop = iterator.next();
			// Adiciona os campos se estiver configurado para gerar código
			if (prop.isGerarCodigo() && !prop.isChavePrimaria()) {				
				codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + "<Rotulo nome=\""+prop.getDisplayCampo()+"\" cols=\""+ prop.getColunaGridCss() +"\" >");
				codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + TABULACAO + "<InputText type=\"text\" v-model=\"registro."+prop.getNomeAtributo() +"\" v-required />");
				codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + "</Rotulo>");				
			}
		}
		codigo.add("");
	}
	
	private String gerarScriptStyle(Entidade entidade) {
		// Cria a lista para armazenar o código em linhas
		List<String> codigo = new ArrayList<String>();
		
		codigo.add("<script>");
		codigo.add("import CardSeplag from '@/template/CardSeplag.vue'");
		codigo.add("import TableSeplag from '@/template/TableSeplag.vue'");
		codigo.add("import Rotulo from '@/template/RotuloSeplag.vue'");
		codigo.add("import CadastroRapido from '@/template/CadRapidoSeplag.vue'");
		codigo.add("import { baseApiUrl } from '@/config/global'");
		codigo.add("");
		codigo.add("const getDefaultState = () => {");
		codigo.add(TABULACAO + "return {");
		
		// Adiciona os campos da constante
		adicionarCamposConst(entidade, codigo);
		
		codigo.add(TABULACAO + "}");
		codigo.add("}");
		codigo.add("");
		codigo.add("export default {");
		codigo.add(TABULACAO + "name: 'Cad"+ entidade.getNomeClasse() +"',");
		codigo.add(TABULACAO + "components: { CardSeplag, TableSeplag, Rotulo, CadastroRapido },");
		codigo.add(TABULACAO + "data: function(){");
		codigo.add(TABULACAO + TABULACAO + "return {");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "exibirTela: false,");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "modoEdicao: 'alterar',");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "dadosTabela: [],");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "apiUrlRecurso: '"+ entidade.getUrlResource() +"',");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "registro: getDefaultState(),");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "colunasTabela: [");
		
		// Adicionad as colunas da grid da tela, neste trecho do código
		adicionarColunasTabela(entidade, codigo);
		
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "]");
		codigo.add(TABULACAO + TABULACAO + "}");
		codigo.add(TABULACAO + "},");
		codigo.add(TABULACAO + "methods: {");
			
		// Adiciona os métodos da tela, neste trecho do código
		adicionarMetodos(entidade, codigo);
		
		codigo.add(TABULACAO + "},");
		codigo.add(TABULACAO + "mounted(){");
		codigo.add(TABULACAO + TABULACAO + "// Carrega os dados do serviço");
		codigo.add(TABULACAO + TABULACAO + "this.carregarDados()");
		codigo.add(TABULACAO + "}");
		codigo.add("}");
		codigo.add("</script>");
		codigo.add("");
		codigo.add("<style scoped>");
		codigo.add("");
		codigo.add("</style>");
		
		// Retorna o código gerado
		return StringUtils.arrayToDelimitedString(codigo.toArray(), "\n");
	}
	
	private void adicionarCamposConst(Entidade entidade, List<String> codigo) {
		// Percorre os campos da entidade
		for (Iterator<Propriedade> iterator = entidade.getPropriedades().iterator(); iterator.hasNext();) {
			// Carrega a propriedade
			Propriedade prop = iterator.next();
			// Adiciona os campos se estiver configurado para gerar código
			if (prop.isGerarCodigo()) {
				codigo.add(TABULACAO + TABULACAO + prop.getNomeAtributo() + ": '',");
			}
		}
		
	}
	
	private void adicionarColunasTabela(Entidade entidade, List<String> codigo) {
		String opcional = "";
		// Percorre os campos da entidade
		for (Iterator<Propriedade> iterator = entidade.getPropriedades().iterator(); iterator.hasNext();) {
			// Carrega a propriedade
			Propriedade prop = iterator.next();
			
			// verifica os campos opcionais
			if (prop.isOcultar()) {
				opcional = ", ocultar: true"; 
			}
			if (!prop.isTamanhoFlexivel()) {
				opcional += ", tamanho: " + Integer.toString(prop.getTamanho());
			}
			if (prop.getMascaraCampo() != null && !prop.getMascaraCampo().isEmpty()) {
				opcional += ", displayFormat: '" + prop.getMascaraCampo() + "'";
			}
			
			// Adiciona os campos se estiver configurado para gerar código
			if (prop.isGerarCodigo()) {
				codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + "{ nome: '"+ prop.getNomeAtributo() +"', titulo: '"+ prop.getDisplayCampo() +"'"+ opcional +" },");
			}
		}
	}
	
	private void adicionarMetodos(Entidade entidade, List<String> codigo) {
		// Carrega os métodos
		codigo.add(TABULACAO + TABULACAO + "limparDados(){");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.modoEdicao = 'adicionar'");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.registro = getDefaultState()");
		codigo.add(TABULACAO + TABULACAO + "},");
		codigo.add(TABULACAO + TABULACAO + "carregarDados(){");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.$http.get(`${baseApiUrl}/${this.apiUrlRecurso}`).then(res => {");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + "this.dadosTabela = res.data.content");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "})");
		//codigo.add(TABULACAO + TABULACAO + TABULACAO + ".catch(err => showError(err, this))");
		codigo.add(TABULACAO + TABULACAO + "},");
		codigo.add(TABULACAO + TABULACAO + "editarRegistro(dado){");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.registro = {...dado}");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.modoEdicao = 'alterar'");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.exibirTela = true");
		codigo.add(TABULACAO + TABULACAO + "},");
		codigo.add(TABULACAO + TABULACAO + "incluirRegistro(){");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.limparDados()");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.modoEdicao = 'adicionar'");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.exibirTela = true");
		codigo.add(TABULACAO + TABULACAO + "},");
		codigo.add(TABULACAO + TABULACAO + "adicionarRegistro(){");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.$http.post(`${baseApiUrl}/${this.apiUrlRecurso}`, JSON.stringify(this.registro))");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + ".then(() => {");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + TABULACAO + "this.$toast.add({severity:'success', summary: 'Registro Adicionado com Sucesso!', life: 3000})");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + TABULACAO + "this.limparDados()");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + TABULACAO + "this.carregarDados()");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + "})");
		//codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + ".catch(err => showError(err, this))");
		codigo.add(TABULACAO + TABULACAO + "},");
		codigo.add(TABULACAO + TABULACAO + "alterarRegistro(){");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.$http.put(`${baseApiUrl}/${this.apiUrlRecurso}/${this.registro."+
						entidade.getChavePrimaria().getNomeAtributo()+"}`, JSON.stringify(this.registro))");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + ".then(() => {");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + TABULACAO + "this.$toast.add({severity:'success', summary: 'Registro Alterado com Sucesso!', life: 3000})");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + TABULACAO + "this.limparDados()");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + TABULACAO + "this.carregarDados()");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + "})");
		//codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + ".catch(err => showError(err, this))");
		codigo.add(TABULACAO + TABULACAO + "},");
		codigo.add(TABULACAO + TABULACAO + "excluirRegistro(dado){");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "this.$http.delete(`${baseApiUrl}/${this.apiUrlRecurso}/${dado."+entidade.getChavePrimaria().getNomeAtributo()+"}`)");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + ".then(() => {");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + TABULACAO + "this.$toast.add({severity:'success', summary: 'Registro Excluido com Sucesso!', life: 3000})");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + TABULACAO + "this.limparDados()");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + TABULACAO + "this.carregarDados()");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + "})");
		//codigo.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + ".catch(err => showError(err, this))");
		codigo.add(TABULACAO + TABULACAO + "}");
	}
}
