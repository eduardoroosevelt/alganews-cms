package br.gov.mt.gestao.ferramenta.vo;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.gov.mt.gestao.thanos.util.TextoUtil;


public class Propriedade implements IDadosNoArvore{

	private String nomeCampo;
	private String nomePropriedade;
	private String displayCampo;
	private String mascaraCampo;
	private int tipoDado;
	private String nomeTipodado;
	private int tamanho;
	private int decimals;
	private boolean campoNulo;
	private boolean chavePrimaria;
	private boolean autoIncremento;
	private String colunaGridCss;
	@JsonIgnore
	private Entidade entidade;
	private boolean tamanhoFlexivel = true;  // Indica que o campo tem o tamanho flexivel
	private boolean gerarCodigo = true;
	private boolean ocultar = false;  // Informa se a campo deve ser exibido na tabela do front-end

	public String getNomeCampo() {
		return nomeCampo;
	}

	public void setNomeCampo(String nomeCampo) {
		// Carrega nome do campo;
		this.nomeCampo = nomeCampo;
		// Formata o nome da propriedade no padrão Java
		setNomePropriedade(TextoUtil.iniMaiuscula(nomeCampo.toLowerCase(),"_",true));
		setDisplayCampo(getNomePropriedade());
	}

	public int getTipoDado() {
		return tipoDado;
	}

	public void setTipoDado(int tipoDado) {
		this.tipoDado = tipoDado;
	}

	public int getTamanho() {
		return tamanho;
	}

	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}

	public String getDisplayCampo() {
		return displayCampo;
	}

	public void setDisplayCampo(String displayCampo) {
		this.displayCampo = displayCampo;
	}

	public String getMascaraCampo() {
		return mascaraCampo;
	}

	public void setMascaraCampo(String mascaraCampo) {
		this.mascaraCampo = mascaraCampo;
	}

	public boolean isCampoNulo() {
		return campoNulo;
	}

	public void setCampoNulo(boolean campoNulo) {
		this.campoNulo = campoNulo;
	}

	public boolean isChavePrimaria() {
		return chavePrimaria;
	}

	public void setChavePrimaria(boolean chavePrimaria) {
		this.chavePrimaria = chavePrimaria;
	}

	public boolean isAutoIncremento() {
		return autoIncremento;
	}

	public void setAutoIncremento(boolean autoIncremento) {
		this.autoIncremento = autoIncremento;
	}

	public String getNomePropriedade() {
		return nomePropriedade;
	}

	public void setNomePropriedade(String nomePropriedade) {
		this.nomePropriedade = nomePropriedade;
	}

	public int getDecimals() {
		return decimals;
	}

	public void setDecimals(int decimals) {
		this.decimals = decimals;
	}

	public Entidade getEntidade() {
		return entidade;
	}

	public void setEntidade(Entidade entidade) {
		this.entidade = entidade;
	}
	
	public String getNomeAtributo() {
		return StringUtils.uncapitalize(getNomePropriedade());
	}

	public boolean isGerarCodigo() {
		return gerarCodigo;
	}

	public void setGerarCodigo(boolean gerarCodigo) {
		this.gerarCodigo = gerarCodigo;
	}

	public String getNomeTipodado() {
		return nomeTipodado;
	}

	public void setNomeTipodado(String nomeTipodado) {
		this.nomeTipodado = nomeTipodado;
	}

	public boolean isOcultar() {
		return ocultar;
	}

	public void setOcultar(boolean ocultar) {
		this.ocultar = ocultar;
	}

	public boolean isTamanhoFlexivel() {
		return tamanhoFlexivel;
	}

	public void setTamanhoFlexivel(boolean tamanhoFlexivel) {
		this.tamanhoFlexivel = tamanhoFlexivel;
	}

	public String getColunaGridCss() {
		return colunaGridCss;
	}

	public void setColunaGridCss(String colunaGridCss) {
		this.colunaGridCss = colunaGridCss;
	}

	@Override
	public String toString() {
		return "Propriedade [nomeCampo=" + nomeCampo + ", nomePropriedade=" + nomePropriedade + ", tipoDado=" + tipoDado
				+ ", nomeTipodado=" + nomeTipodado + ", tamanho=" + tamanho + ", decimals=" + decimals + ", campoNulo="
				+ campoNulo + ", chavePrimaria=" + chavePrimaria + ", autoIncremento=" + autoIncremento + ", gerarCodigo=" + gerarCodigo + "]";
	}

	@Override
	public String getNomeDado() {
		return getNomeCampo();
	}

	@Override
	public String getNomeObjeto() {
		return getNomeAtributo();
	}

	@Override
	public String getDisplayObjeto() {
		return getDisplayCampo();
	}

	@Override
	public EnumTipoDadoNo getTipoDadoNo() {
		return EnumTipoDadoNo.PROPRIEDADE;
	}

}
