package br.gov.mt.gestao.ferramenta.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Arvore implements Serializable{

	private static final long serialVersionUID = 1L;

	private ProjetoGerador projeto;
	private List<NoArvore> root = new ArrayList<NoArvore>();	

	public ProjetoGerador getProjeto() {
		return projeto;
	}

	public void setProjeto(ProjetoGerador projeto) {
		this.projeto = projeto;
	}

	public List<NoArvore> getRoot() {
		return root;
	}

	public void setRoot(List<NoArvore> root) {
		this.root = root;
	}
	
}
