package br.gov.mt.gestao.ferramenta.service.geracao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.gov.mt.gestao.ferramenta.vo.Entidade;

@Component
public class GeracaoResource {

	public static final String TABULACAO = "\t";
	
	private String nomeVariavelClasse;
	private String nomeClasse;
	private String pathResource;
	
	public String gerarCodigo(Entidade entidade) {
		String codigoTxt = "";
		// Carrega o nome da classe como variavel
		nomeVariavelClasse = entidade.getNomeClasse().toLowerCase();
		nomeClasse = entidade.getNomeClasse();
		// Carrega a path do resource gerada
		setPathResource(nomeVariavelClasse, entidade);
		
		codigoTxt += codigoPacote(entidade) + "\n\n";
		
		codigoTxt += codigoImportLib(entidade) + "\n\n";
		
		codigoTxt += codigoInicioClasse(entidade) + "\n\n";
		
		codigoTxt += codigoCriarResource(entidade) + "\n\n";
		
		codigoTxt += codigoBuscarId(entidade) + "\n\n";
		
		codigoTxt += codigoAtualizar(entidade) + "\n\n";
		
		codigoTxt += codigoPesquisar(entidade) + "\n\n";
		
		codigoTxt += codigoRemover(entidade) + "\n\n";
		
		return codigoTxt + "}";
	}
	
	private String declaracaoVarClasse(String sufixo) {
		return nomeClasse + sufixo + " " + nomeVariavelClasse + sufixo; 
	}
	
	private String codigoImportLib(Entidade entidade){
		List<String> importLib = new ArrayList<String>();
		// Adicona os imports basicos da entidade 
		importLib.add("import javax.servlet.http.HttpServletResponse;");
		importLib.add("import javax.validation.Valid;");
		importLib.add("import java.util.List;");
		importLib.add("");
		importLib.add("import org.springframework.beans.factory.annotation.Autowired;");
		importLib.add("import org.springframework.context.ApplicationEventPublisher;");
		importLib.add("import org.springframework.data.domain.Page;");
		importLib.add("import org.springframework.data.domain.Pageable;");
		importLib.add("import org.springframework.http.HttpStatus;");
		importLib.add("import org.springframework.http.ResponseEntity;");
		importLib.add("import org.springframework.web.bind.annotation.DeleteMapping;");
		importLib.add("import org.springframework.web.bind.annotation.GetMapping;");
		importLib.add("import org.springframework.web.bind.annotation.PathVariable;");
		importLib.add("import org.springframework.web.bind.annotation.PostMapping;");
		importLib.add("import org.springframework.web.bind.annotation.PutMapping;");
		importLib.add("import org.springframework.web.bind.annotation.RequestBody;");
		importLib.add("import org.springframework.web.bind.annotation.RequestMapping;");
		importLib.add("import org.springframework.web.bind.annotation.ResponseStatus;");
		importLib.add("import org.springframework.web.bind.annotation.RestController;");
		importLib.add("");
		importLib.add("import " + entidade.getPacoteCompleto() + ".model." + nomeClasse + ";");
		importLib.add("import " + entidade.getPacoteCompleto() + ".service." + nomeClasse + "Service;");
		importLib.add("import br.gov.mt.gestao.thanos.event.RecursoCriadoEvent;");
		
		
		// Retorna o Código Restante
		return StringUtils.arrayToDelimitedString(importLib.toArray(), "\n");
	}
	
	private String codigoPacote(Entidade entidade) {
		return "package " + entidade.getPacoteCompleto() + ".resource;";
	}
	
	private String codigoInicioClasse(Entidade entidade) {
		List<String> codigoIni = new ArrayList<String>();
		codigoIni.add("@RestController");
		codigoIni.add("@RequestMapping(\"/"+ getPathResource() +"\")");
		codigoIni.add("public class "+ nomeClasse +"Resource {");
		codigoIni.add("");
		codigoIni.add(TABULACAO + "@Autowired");
		codigoIni.add(TABULACAO + "private "+ declaracaoVarClasse("Service") +";");
		codigoIni.add("");
		codigoIni.add(TABULACAO + "@Autowired");
		codigoIni.add(TABULACAO + "private ApplicationEventPublisher publisher;");
		// Retorna o código inicial da classe
		return StringUtils.arrayToDelimitedString(codigoIni.toArray(), "\n");
	}
	
	private String codigoCriarResource(Entidade entidade) {
		List<String> codigoCriar = new ArrayList<String>();
		codigoCriar.add(TABULACAO + "@PostMapping");
		codigoCriar.add(TABULACAO + "public ResponseEntity<"+ nomeClasse +"> criar(@Valid @RequestBody " + 
				declaracaoVarClasse("") + ", HttpServletResponse response) {");
		codigoCriar.add(TABULACAO + TABULACAO + " " + nomeClasse + " " + nomeVariavelClasse +"Salva = "+ nomeVariavelClasse +"Service.salvar("+nomeVariavelClasse+");");
		codigoCriar.add(TABULACAO + TABULACAO + "publisher.publishEvent(new RecursoCriadoEvent(this, response, " + 
					nomeVariavelClasse +"Salva.get"+ entidade.getChavePrimaria().getNomePropriedade() +"()));");
		codigoCriar.add(TABULACAO + TABULACAO + "return ResponseEntity.status(HttpStatus.CREATED).body(" + nomeVariavelClasse +"Salva);");
		codigoCriar.add(TABULACAO + "}");
		return StringUtils.arrayToDelimitedString(codigoCriar.toArray(), "\n");
	}
	
	private String codigoBuscarId(Entidade entidade) {
		List<String> codigo = new ArrayList<String>();
		codigo.add(TABULACAO + "@GetMapping(\"/{codigo}\")");
		codigo.add(TABULACAO + "public ResponseEntity<"+ nomeClasse +"> buscarPeloCodigo(@PathVariable Long codigo) {");
		codigo.add(TABULACAO + TABULACAO + declaracaoVarClasse("") + " = "+ nomeVariavelClasse +"Service.buscarPeloCodigo(codigo);");
		codigo.add(TABULACAO + TABULACAO + "return "+ nomeVariavelClasse +" != null ? ResponseEntity.ok("+ nomeVariavelClasse +") : ResponseEntity.notFound().build();");
		codigo.add(TABULACAO + "}");
		return StringUtils.arrayToDelimitedString(codigo.toArray(), "\n");
	}
	
	private String codigoAtualizar(Entidade entidade) {
		List<String> codigo = new ArrayList<String>();
		codigo.add(TABULACAO + "@PutMapping(\"/{codigo}\")");
		codigo.add(TABULACAO + "public ResponseEntity<"+ nomeClasse +"> atualizar(@PathVariable Long codigo, @Valid @RequestBody "+ declaracaoVarClasse("") +") {");
		codigo.add(TABULACAO + TABULACAO + declaracaoVarClasse("") + "Salva = "+ nomeVariavelClasse +"Service.atualizar(codigo, "+ nomeVariavelClasse +");");
		codigo.add(TABULACAO + TABULACAO + "return ResponseEntity.ok("+ nomeVariavelClasse +"Salva);");
		codigo.add(TABULACAO + "}");
		return StringUtils.arrayToDelimitedString(codigo.toArray(), "\n");
	}

	private String codigoPesquisar(Entidade entidade) {
		List<String> codigo = new ArrayList<String>();
		codigo.add(TABULACAO + "@GetMapping");
		codigo.add(TABULACAO + "public Page<"+ nomeClasse +"> pesquisar(Pageable pageable) {");
		codigo.add(TABULACAO + TABULACAO +"return "+ nomeVariavelClasse +"Service.pesquisar(pageable);");
		codigo.add(TABULACAO + "}");
		codigo.add("");
		codigo.add(TABULACAO + "@GetMapping(\"/all\")");
		codigo.add(TABULACAO + "public List<"+ nomeClasse +"> pesquisar() {");
		codigo.add(TABULACAO + TABULACAO + "return "+ nomeVariavelClasse +"Service.listarTodos();");
		codigo.add(TABULACAO + "}");	
		
		return StringUtils.arrayToDelimitedString(codigo.toArray(), "\n");		
	}
	
	private String codigoRemover(Entidade entidade) {
		List<String> codigo = new ArrayList<String>();
		codigo.add(TABULACAO + "@DeleteMapping(\"/{codigo}\")");
		codigo.add(TABULACAO + "@ResponseStatus(HttpStatus.NO_CONTENT)");
		codigo.add(TABULACAO +"public void remover(@PathVariable Long codigo) {");
		codigo.add(TABULACAO + TABULACAO + nomeVariavelClasse + "Service.remover(codigo);");
		codigo.add(TABULACAO + "}");
		return StringUtils.arrayToDelimitedString(codigo.toArray(), "\n");
	}

	public String getPathResource() {
		return pathResource;
	}

	private void setPathResource(String pathResource, Entidade entidade) {
		String pathRet = ""; 
		// Se não foi informado a URL na entidade carrega este valor
		if (entidade.getUrlResource() == null || entidade.getUrlResource().isEmpty()) {
			// Efetua o tratamento para gerar a path do resource
			if (pathResource.endsWith("s")) {
				pathRet = pathResource;
			}
			else {
				pathRet = pathResource + "s";
			}
			// Carrega a url do resource na entidade
			entidade.setUrlResource(pathRet);
		}
		else {
			pathRet = entidade.getUrlResource();
		}
		this.pathResource = pathRet;
	}
}
