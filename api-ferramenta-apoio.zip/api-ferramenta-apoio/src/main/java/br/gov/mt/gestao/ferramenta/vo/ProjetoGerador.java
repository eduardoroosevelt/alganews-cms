package br.gov.mt.gestao.ferramenta.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ProjetoGerador implements Serializable{

	private static final long serialVersionUID = 1L;

	private String nomeSistema;
	private String urlBaseApi;
	private String database;
	private String urlJdbc;
	private String username;
	private String password;
	private String dialectDatabase;
	private String nomeSchema;
	private int tamamhoPrefixo;  // Informa a quantidade de caracteres do prefixo do nome da tabela
	private String pathArquivosSaida; // Path do local onde será salvo os arquivos gerados do projeto
	private String pacoteCompleto;    // nome completo do pacote que o projeto deve ser gerado. ex: br.gov.mt.seplag.controle
	private boolean gerarControleAcesso = false; // Gerar as TAGS de controle de acesso na aplicação (Importar o Thanos-Security)
	private boolean ignorarChavePrimaria = false; // Ignora a chave primaria na geração do código
	private List<Entidade> entidades;

	public ProjetoGerador() {
		super();
		entidades =  new ArrayList<Entidade>();
	}
	
	public String getNomeSistema() {
		return nomeSistema;
	}

	public void setNomeSistema(String nomeSistema) {
		this.nomeSistema = nomeSistema;
	}

	public String getUrlBaseApi() {
		return urlBaseApi;
	}

	public void setUrlBaseApi(String urlBaseApi) {
		this.urlBaseApi = urlBaseApi;
	}

	public String getDatabase() {
		return database;
	}

	public void setDatabase(String database) {
		this.database = database;
	}

	public String getUrlJdbc() {
		return urlJdbc;
	}

	public void setUrlJdbc(String urlJdbc) {
		this.urlJdbc = urlJdbc;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDialectDatabase() {
		return dialectDatabase;
	}

	public void setDialectDatabase(String dialectDatabase) {
		this.dialectDatabase = dialectDatabase;
	}

	public List<Entidade> getEntidades() {
		return entidades;
	}

	public void setEntidades(List<Entidade> entidades) {
		this.entidades = entidades;
	}

	public String getPathArquivosSaida() {
		return pathArquivosSaida;
	}

	public void setPathArquivosSaida(String pathArquivosSaida) {
		this.pathArquivosSaida = pathArquivosSaida;
	}

	public String getPacoteCompleto() {
		return pacoteCompleto;
	}

	public void setPacoteCompleto(String pacoteCompleto) {
		this.pacoteCompleto = pacoteCompleto;
	}

	public boolean isGerarControleAcesso() {
		return gerarControleAcesso;
	}

	public void setGerarControleAcesso(boolean gerarControleAcesso) {
		this.gerarControleAcesso = gerarControleAcesso;
	}

	public int getTamamhoPrefixo() {
		return tamamhoPrefixo;
	}

	public void setTamamhoPrefixo(int tamamhoPrefixo) {
		this.tamamhoPrefixo = tamamhoPrefixo;
	}

	public boolean isIgnorarChavePrimaria() {
		return ignorarChavePrimaria;
	}

	public void setIgnorarChavePrimaria(boolean ignorarChavePrimaria) {
		this.ignorarChavePrimaria = ignorarChavePrimaria;
	}

	public String getNomeSchema() {
		return nomeSchema;
	}

	public void setNomeSchema(String nomeSchema) {
		this.nomeSchema = nomeSchema;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nomeSistema == null) ? 0 : nomeSistema.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProjetoGerador other = (ProjetoGerador) obj;
		if (nomeSistema == null) {
			if (other.nomeSistema != null)
				return false;
		} else if (!nomeSistema.equals(other.nomeSistema))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ProjetoGerador [nomeSistema=" + nomeSistema + ", urlBaseApi=" + urlBaseApi + "]";
	}

}
