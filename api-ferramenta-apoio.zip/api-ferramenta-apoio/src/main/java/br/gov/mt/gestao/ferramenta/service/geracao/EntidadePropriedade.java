package br.gov.mt.gestao.ferramenta.service.geracao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.gov.mt.gestao.ferramenta.vo.Propriedade;

@Component
public class EntidadePropriedade {
	
	public static final String TABULACAO = "\t";
	
	public static int[] TIPOS_INTEIROS = {-5,-6,-7, 4, 5};
	int[] TIPOS_DOUBLE = {2, 3, 6, 7, 8};
	int[] TIPOS_DATA = {91, 92, 93, 2013, 2014};
	
	public String codigoCabecalho(Propriedade propriedade){
		List<String> cabProp = new ArrayList<String>();
		// Verifica se é chave primária
		if (propriedade.isChavePrimaria()) {
			cabProp.add(TABULACAO +"@Id");
			// Verifica se o tipo é autoincremento
			if (propriedade.isAutoIncremento()) {
				cabProp.add(TABULACAO +"@GeneratedValue(strategy = GenerationType.IDENTITY)");
			}
		}
		// Se a propriedade for do tipo data adiciona o mapeamento de Data
		if(isCampoTipodata(propriedade)) {
			cabProp.add(TABULACAO +"@Temporal(TemporalType.TIMESTAMP)");
		}
		// Código da declaração da propriedade
		cabProp.add(TABULACAO +"@Column(name = \"" + propriedade.getNomeCampo() + "\")");
		cabProp.add(TABULACAO + "private " + tipoDadoPropriedade(propriedade) + 
				    " " + propriedade.getNomeAtributo() + ";\n");
		return StringUtils.arrayToDelimitedString(cabProp.toArray(), "\n"); 
	}
	
	public String codigoCorpo(Propriedade propriedade){
		List<String> corpoProp = new ArrayList<String>();
		// Monta o corpo da propriedade - método get
		corpoProp.add(TABULACAO + "public " + tipoDadoPropriedade(propriedade) + 
				      " get" + propriedade.getNomePropriedade() + "() {");
		corpoProp.add(TABULACAO + TABULACAO + "return " + propriedade.getNomeAtributo() +";");
		corpoProp.add(TABULACAO + "}");
		// Linha entre os métodos
		corpoProp.add(TABULACAO + " ");
		// Monta o corpo da propriedade - método set
		corpoProp.add(TABULACAO + "public void set" + propriedade.getNomePropriedade() + 
				      "(" +tipoDadoPropriedade(propriedade) + " " + propriedade.getNomeAtributo() + ") {");
		corpoProp.add(TABULACAO + TABULACAO + "this." + propriedade.getNomeAtributo() + " = " + propriedade.getNomeAtributo() +  ";");
		corpoProp.add(TABULACAO + "}");
		corpoProp.add(TABULACAO + " ");
		
		// Retorna o corpo da propriedade montado
		return StringUtils.arrayToDelimitedString(corpoProp.toArray(), "\n");
	}

	public String codigoHashCode(Propriedade propriedade, String chaveId) {
		List<String> codHash = new ArrayList<String>();
		codHash.add(TABULACAO + "@Override");
		codHash.add(TABULACAO + "public int hashCode() {");
		codHash.add(TABULACAO + TABULACAO + "final int prime = 31;");
		codHash.add(TABULACAO + TABULACAO + "int result = 1;");
		codHash.add(TABULACAO + TABULACAO + "result = prime * result + (("+ propriedade.getNomeAtributo() + 
				    " == null) ? 0 : " + propriedade.getNomeAtributo() + ".hashCode());");
		codHash.add(TABULACAO + TABULACAO + "return result;");
		codHash.add(TABULACAO + "}");
		
		codHash.add(TABULACAO + " ");
		
		codHash.add(TABULACAO + "@Override");
		codHash.add(TABULACAO + "public boolean equals(Object obj) {");
		codHash.add(TABULACAO + TABULACAO + "if (this == obj)");
		codHash.add(TABULACAO + TABULACAO + TABULACAO + "return true;");
		codHash.add(TABULACAO + TABULACAO + "if (obj == null)");
		codHash.add(TABULACAO + TABULACAO + TABULACAO + "return false;");
		codHash.add(TABULACAO + TABULACAO + "if (getClass() != obj.getClass())");
		codHash.add(TABULACAO + TABULACAO + TABULACAO + "return false;");
		codHash.add(TABULACAO + TABULACAO + propriedade.getEntidade().getNomeClasse() + " other = (" +
		            propriedade.getEntidade().getNomeClasse() + ") obj;");
		codHash.add(TABULACAO + TABULACAO + "if (" + propriedade.getNomeAtributo() +" == null) {");
		codHash.add(TABULACAO + TABULACAO + TABULACAO + "if (other." + propriedade.getNomeAtributo() + " != null)");
		codHash.add(TABULACAO + TABULACAO + TABULACAO + TABULACAO + "return false;");
		codHash.add(TABULACAO + TABULACAO + "} else if (!" + propriedade.getNomeAtributo() + ".equals(other."+ chaveId +"))");
		codHash.add(TABULACAO + TABULACAO + TABULACAO + "return false;");
		codHash.add(TABULACAO + TABULACAO + "return true;");
		codHash.add(TABULACAO + "}");
		
		// Retorna o corpo da propriedade montado
		return StringUtils.arrayToDelimitedString(codHash.toArray(), "\n");
	}
	
	private String tipoDadoPropriedade(Propriedade propriedade) {
		
		if (propriedade.isChavePrimaria()) {
			return "Long";
		}
		else if (Arrays.binarySearch(TIPOS_INTEIROS, propriedade.getTipoDado()) > 0) {
			return "Integer";
		}
		else if (Arrays.binarySearch(TIPOS_DOUBLE, propriedade.getTipoDado()) > 0) {
			return "Double";
		}
		else if (isCampoTipodata(propriedade)) {
			// Adiciona a blioteca necessária para o tipo Data e Hora
			propriedade.getEntidade().getImportLib().put("Data", "import java.util.Date;");
			propriedade.getEntidade().getImportLib().put("Temporal", "import javax.persistence.Temporal;");
			propriedade.getEntidade().getImportLib().put("TemporalType", "import javax.persistence.TemporalType;");
			return "Date";
		}
		else {
			return "String";
		}
	}
	
	private boolean isCampoTipodata(Propriedade propriedade) {
		return (Arrays.binarySearch(TIPOS_DATA, propriedade.getTipoDado()) > 0);
	}
}
