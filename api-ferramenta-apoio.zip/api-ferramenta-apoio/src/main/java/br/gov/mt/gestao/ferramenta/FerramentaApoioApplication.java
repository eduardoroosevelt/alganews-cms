package br.gov.mt.gestao.ferramenta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("br.gov.mt.gestao")
public class FerramentaApoioApplication {

	public static void main(String[] args) {
		SpringApplication.run(FerramentaApoioApplication.class, args);
	}

}
