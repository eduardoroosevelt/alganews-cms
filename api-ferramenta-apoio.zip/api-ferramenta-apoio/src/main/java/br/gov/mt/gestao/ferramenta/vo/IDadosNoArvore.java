package br.gov.mt.gestao.ferramenta.vo;

public interface IDadosNoArvore {

	public String getNomeDado(); // Nome da tabela ou do campo, dados de origem
	
	public String getNomeObjeto(); // Nome da classe ou propriedade da tabela
	
	public String getDisplayObjeto(); // Texto a ser exibido na tela
	
	public EnumTipoDadoNo getTipoDadoNo(); // Retorna o tipo de dado do no 
	
	public void setGerarCodigo(boolean valor); // Seta se o objeto deve ser gerado 
}
