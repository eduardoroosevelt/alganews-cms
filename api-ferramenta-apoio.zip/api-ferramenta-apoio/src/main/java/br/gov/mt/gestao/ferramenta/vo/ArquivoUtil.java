package br.gov.mt.gestao.ferramenta.vo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.apache.commons.codec.binary.Base64;

public class ArquivoUtil {

	public static boolean gerarArquivoJava(String conteudo, String nomeArquivo, String pathArquivo) throws IOException {
		// Cria o arquivo com o nome e o local informado
		FileWriter arq = new FileWriter(pathArquivo + "/" + nomeArquivo);
		try {
		    PrintWriter gravarArq = new PrintWriter(arq);
			
		    // Grava o conteudo repassado no arquivo
		    gravarArq.printf(conteudo);
		    // Retorna sucesso na geração do arquivo
		    return true;
		}    
		finally {
			// Fecha o arquivo
		    arq.close();
		}		
	}
	
	public static boolean criarDiretorio(String nomeDiretorio) {
		// Cria o diretorio
		return (new File(nomeDiretorio)).mkdir();
	}
	
	
	public static String converterArquivoBase64(byte[] arquivoPdf) {
		// Converte um arquivo PDF para Base64
		return new String(Base64.encodeBase64(arquivoPdf));
	}
}
