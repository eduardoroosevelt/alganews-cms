package br.gov.mt.gestao.ferramenta.vo;

import java.io.Serializable;

public class FuncionalidadeRole implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private EnumAcaoFuncionalidade funcionalidade;
	private String nomeRole;

	public EnumAcaoFuncionalidade getFuncionalidade() {
		return funcionalidade;
	}

	public void setFuncionalidade(EnumAcaoFuncionalidade funcionalidade) {
		this.funcionalidade = funcionalidade;
	}

	public String getNomeRole() {
		return nomeRole;
	}

	public void setNomeRole(String nomeRole) {
		this.nomeRole = nomeRole;
	}
}
