package br.gov.mt.gestao.ferramenta.service.geracao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.gov.mt.gestao.ferramenta.vo.Entidade;

@Component
public class GerarService {

	public static final String TABULACAO = "\t";
	
	private String nomeVariavelClasse;
	private String nomeClasse;
	
	public String gerarCodigo(Entidade entidade) {
		String codigoTxt = "";
		// Carrega o nome da classe como variavel
		nomeVariavelClasse = entidade.getNomeClasse().toLowerCase();
		nomeClasse = entidade.getNomeClasse();
		
		codigoTxt += codigoPacote(entidade) + "\n\n";
		
		codigoTxt += codigoImportLib(entidade) + "\n\n";
		
		codigoTxt += codigoInicioClasse(entidade) + "\n\n";
		
		codigoTxt += codigoCriar(entidade) + "\n\n";
		
		codigoTxt += codigoBuscarId(entidade) + "\n\n";
		
		codigoTxt += codigoAtualizar(entidade) + "\n\n";
		
		codigoTxt += codigoPesquisar(entidade) + "\n\n";
		
		codigoTxt += codigoRemover(entidade) + "\n\n";
		
		return codigoTxt + "}";
	}
	
	private String declaracaoVarClasse(String sufixo) {
		return nomeClasse + sufixo + " " + nomeVariavelClasse + sufixo; 
	}
	
	private String codigoImportLib(Entidade entidade){
		List<String> importLib = new ArrayList<String>();
		// Adicona os imports basicos da entidade
		importLib.add("import java.util.List;");
		importLib.add("");
		importLib.add("import org.springframework.beans.BeanUtils;");
		importLib.add("import org.springframework.beans.factory.annotation.Autowired;");
		importLib.add("import org.springframework.dao.EmptyResultDataAccessException;");
		importLib.add("import org.springframework.data.domain.Page;");
		importLib.add("import org.springframework.data.domain.Pageable;");
		importLib.add("import org.springframework.stereotype.Service;");
		importLib.add("");
		importLib.add("import " + entidade.getPacoteCompleto() + ".model." + nomeClasse + ";");
		importLib.add("import " + entidade.getPacoteCompleto() + ".repository." + nomeClasse + "Repository;");
		
		// Retorna o Código Restante
		return StringUtils.arrayToDelimitedString(importLib.toArray(), "\n");
	}
	
	private String codigoPacote(Entidade entidade) {
		return "package " + entidade.getPacoteCompleto() + ".service;";
	}
	
	private String codigoInicioClasse(Entidade entidade) {
		List<String> codigoIni = new ArrayList<String>();
		codigoIni.add("@Service");
		codigoIni.add("public class "+ nomeClasse +"Service {");
		codigoIni.add("");
		codigoIni.add(TABULACAO + "@Autowired");
		codigoIni.add(TABULACAO + "private "+ declaracaoVarClasse("Repository") +";");
		// Retorna o código inicial da classe
		return StringUtils.arrayToDelimitedString(codigoIni.toArray(), "\n");
	}
	
	private String codigoCriar(Entidade entidade) {
		List<String> codigoCriar = new ArrayList<String>();
		codigoCriar.add(TABULACAO + "public "+ nomeClasse +" salvar("+ declaracaoVarClasse("") +") {");
		codigoCriar.add(TABULACAO + TABULACAO + "return "+ nomeVariavelClasse +"Repository.save("+ nomeVariavelClasse +");");
		codigoCriar.add(TABULACAO + "}");
		return StringUtils.arrayToDelimitedString(codigoCriar.toArray(), "\n");
	}
	
	private String codigoBuscarId(Entidade entidade) {
		List<String> codigo = new ArrayList<String>();
		codigo.add(TABULACAO + "public "+ nomeClasse +" buscarPeloCodigo(Long codigo) {");
		codigo.add(TABULACAO + TABULACAO +  declaracaoVarClasse("") + "Salva = "+ nomeVariavelClasse +"Repository.findById(codigo).get();");
		codigo.add(TABULACAO + TABULACAO + "if ("+ nomeVariavelClasse +"Salva == null) {");
		codigo.add(TABULACAO + TABULACAO + "throw new EmptyResultDataAccessException(1);");
		codigo.add(TABULACAO + TABULACAO + TABULACAO + "}");
		codigo.add(TABULACAO + TABULACAO + "return "+ nomeVariavelClasse +"Salva;");
		codigo.add(TABULACAO + "}");
		return StringUtils.arrayToDelimitedString(codigo.toArray(), "\n");
	}
	
	private String codigoAtualizar(Entidade entidade) {
		List<String> codigo = new ArrayList<String>();
		
		//System.out.println(entidade);
		
		codigo.add(TABULACAO + "public "+ nomeClasse +" atualizar(Long codigo, "+ declaracaoVarClasse("") +") {");
		codigo.add(TABULACAO + TABULACAO + declaracaoVarClasse("") + "Save = buscarPeloCodigo(codigo);");
		codigo.add(TABULACAO + TABULACAO + "BeanUtils.copyProperties("+ nomeVariavelClasse +", "+ nomeVariavelClasse +"Save, \""+ entidade.getChavePrimaria().getNomeAtributo() +"\");");
		codigo.add(TABULACAO + TABULACAO + "return "+ nomeVariavelClasse +"Repository.save("+ nomeVariavelClasse +"Save);");
		codigo.add(TABULACAO + "}");
		
		return StringUtils.arrayToDelimitedString(codigo.toArray(), "\n");
	}

	private String codigoPesquisar(Entidade entidade) {
		List<String> codigo = new ArrayList<String>();
		codigo.add(TABULACAO + "public Page<"+ nomeClasse +"> pesquisar(Pageable pageable){");
		codigo.add(TABULACAO + TABULACAO +"return "+ nomeVariavelClasse +"Repository.findAll(pageable);");
		codigo.add(TABULACAO + "}");
		codigo.add("");
		codigo.add(TABULACAO + "public List<"+ nomeClasse +"> listarTodos() {");
		codigo.add(TABULACAO + TABULACAO + "return " + nomeVariavelClasse + "Repository.findAll();");
		codigo.add(TABULACAO + "}");
		
		return StringUtils.arrayToDelimitedString(codigo.toArray(), "\n");		
	}
	
	private String codigoRemover(Entidade entidade) {
		List<String> codigo = new ArrayList<String>();
		codigo.add(TABULACAO +"public void remover(Long codigo) {");
		codigo.add(TABULACAO + TABULACAO + nomeVariavelClasse + "Repository.deleteById(codigo);");
		codigo.add(TABULACAO + "}");
		
		return StringUtils.arrayToDelimitedString(codigo.toArray(), "\n");
	}
}
