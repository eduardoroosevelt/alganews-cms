package br.gov.mt.gestao.ferramenta.resource;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.gov.mt.gestao.ferramenta.service.GerarEntidadeService;
import br.gov.mt.gestao.ferramenta.vo.Arvore;
import br.gov.mt.gestao.ferramenta.vo.ProjetoGerador;

@RestController
@RequestMapping("entidades")
public class GerarEntidadeResource {

	@Autowired
	private GerarEntidadeService gerarEntidadeService;
	
	@GetMapping
	public List<String> listarTabelas() throws Exception{
		return gerarEntidadeService.listarTabelas();
	}
	
	@PostMapping
	public Arvore listarEntidades(@RequestBody ProjetoGerador projeto) throws SQLException, IOException {
		// Carrega a estrutura do projeto
		Arvore arvore = gerarEntidadeService.carregarEntidadesBanco(projeto);

		// Gera os arquivos do projeto
		gerarEntidadeService.gerarCodigosClasses(projeto);
		return arvore;
	}
}
