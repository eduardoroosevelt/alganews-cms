package br.gov.mt.gestao.ferramenta.vo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Transient;

public class Entidade implements IDadosNoArvore{

	private String nomeTabela;
	private String nomeClasse;
	private String pacoteCompleto;
	private String nomeSchema;
	private String nomeTela; // Texto a ser exibido no titulo da tela 
	private String urlResource; // URL de acesso ao resource da API 
	private List<Propriedade> propriedades;
	private Propriedade chavePrimaria;
	private List<ChaveEstrangeira> chaveEstrangeiras;
	private List<FuncionalidadeRole> funcionalidades;
	private boolean gerarCodigo = true;
	@Transient
	private Map<String, String> importLib;

	public Entidade() {
		propriedades = new ArrayList<Propriedade>();
		chaveEstrangeiras = new ArrayList<ChaveEstrangeira>();
		importLib = new HashMap<>();
	}

	public String getNomeTabela() {
		return nomeTabela;
	}

	public void setNomeTabela(String nomeTabela) {
		this.nomeTabela = nomeTabela;
	}

	public String getPacoteCompleto() {
		return pacoteCompleto;
	}

	public void setPacoteCompleto(String pacoteCompleto) {
		this.pacoteCompleto = pacoteCompleto;
	}

	public Map<String, String> getImportLib() {
		return importLib;
	}

	public void setImportLib(Map<String, String> importLib) {
		this.importLib = importLib;
	}

	public List<Propriedade> getPropriedades() {
		return propriedades;
	}

	public Propriedade getChavePrimaria() {
		return chavePrimaria;
	}

	public void setChavePrimaria(Propriedade chavePrimaria) {
		this.chavePrimaria = chavePrimaria;
	}

	public String getNomeTela() {
		return nomeTela;
	}

	public void setNomeTela(String nomeTela) {
		this.nomeTela = nomeTela;
	}

	public List<FuncionalidadeRole> getFuncionalidades() {
		return funcionalidades;
	}

	public void setFuncionalidades(List<FuncionalidadeRole> funcionalidades) {
		this.funcionalidades = funcionalidades;
	}

	public String getNomeSchema() {
		return nomeSchema;
	}

	public void setNomeSchema(String nomeSchema) {
		this.nomeSchema = nomeSchema;
	}

	public void setPropriedades(List<Propriedade> propriedades) {
		this.propriedades = propriedades;
	}

	public void setPropriedade(Propriedade propriedade) {
		// Adicona a propriedade na lista
		propriedades.add(propriedade);
		// Adiciona a referencia da classe entidade na propriedade
		propriedade.setEntidade(this);
	}

	public String getNomeClasse() {
		return nomeClasse;
	}

	public void setNomeClasse(String nomeClasse) {
		this.nomeClasse = nomeClasse;
	}

	public boolean isGerarCodigo() {
		return gerarCodigo;
	}

	public void setGerarCodigo(boolean gerarCodigo) {
		this.gerarCodigo = gerarCodigo;
	}

	public List<ChaveEstrangeira> getChaveEstrangeiras() {
		return chaveEstrangeiras;
	}

	public void setChaveEstrangeiras(List<ChaveEstrangeira> chaveEstrangeiras) {
		this.chaveEstrangeiras = chaveEstrangeiras;
	}

	public String getUrlResource() {
		return urlResource;
	}

	public void setUrlResource(String urlResource) {
		this.urlResource = urlResource;
	}

	@Override
	public String getNomeDado() {
		return getNomeTabela();
	}

	@Override
	public String getNomeObjeto() {
		return getNomeClasse();
	}

	@Override
	public String getDisplayObjeto() {
		return getNomeTela();
	}

	@Override
	public EnumTipoDadoNo getTipoDadoNo() {
		return EnumTipoDadoNo.CLASSE;
	}

	@Override
	public String toString() {
		return "Entidade [nomeTabela=" + nomeTabela + ", nomeClasse=" + nomeClasse + ", propriedades=" + propriedades
				+ ", chavePrimaria=" + chavePrimaria + ", chaveEstrangeiras=" + chaveEstrangeiras + "]";
	}

}
