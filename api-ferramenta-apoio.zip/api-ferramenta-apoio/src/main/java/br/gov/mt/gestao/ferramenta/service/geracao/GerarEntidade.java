package br.gov.mt.gestao.ferramenta.service.geracao;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.gov.mt.gestao.ferramenta.vo.Entidade;
import br.gov.mt.gestao.ferramenta.vo.Propriedade;

@Component
public class GerarEntidade {

	@Autowired
	private EntidadeClasse entidadeClasse;

	@Autowired
	private EntidadePropriedade entidadePropriedade;

	public String gerarCodigoEntidade(Entidade entidade) {
		// Texto do código java
		String codigoTxt = "";
		String codHash = "";
		String props = "";

		// Carrega as propriedades para gerar os imports necessários 
		props = gerarPropriedades(entidade, codHash);
		
		// Carrega o código inicial da classe
		codigoTxt = codigoTxt + entidadeClasse.codigoPacote(entidade) + "\n\n";

		// Carrega os imports
		codigoTxt = codigoTxt + entidadeClasse.codigoImportLib(entidade) + "\n\n";

		// Carrega o inicio da classe
		codigoTxt = codigoTxt + entidadeClasse.codigoInicioClasse(entidade) + "\n\n";
		
		// Montar o corpo das propriedades
		codigoTxt = codigoTxt + props;

		// Carrega o código do hashCode e Equals
		codigoTxt = codigoTxt + codHash + "\n";

		// Final do corpo da classe
		codigoTxt = codigoTxt + entidadeClasse.codigoFimClasse() + "\n";

		// Retorna o código
		return codigoTxt;
	}

	private String gerarPropriedades(Entidade entidade, String codHash) {
		String cabecalhoProp = "";
		String corpoProp = "";

		// Carrega as propriedades da classe
		for (Iterator<Propriedade> iterator = entidade.getPropriedades().iterator(); iterator.hasNext();) {
			// Carrega a propriedade da classe
			Propriedade prop = iterator.next();
			
			// Se a propriedade não deve gerar código vai para o próximo item
			if (!prop.isGerarCodigo()) {
				continue;
			}
			
			// Gera o cabeçalho da propriedade
			cabecalhoProp = cabecalhoProp + entidadePropriedade.codigoCabecalho(prop) + "\n";
			// Gera o corpo da propriedade
			corpoProp = corpoProp + entidadePropriedade.codigoCorpo(prop) + "\n";
			if (prop.isChavePrimaria()) {
				// Carrega a referencia da chave primaria
				entidade.setChavePrimaria(prop);
				// Carrega o código hash
				codHash = entidadePropriedade.codigoHashCode(prop, prop.getNomeAtributo());
			}
		}
		// Retorna o código das propriedades da classe
		return cabecalhoProp + corpoProp;
	}
}

