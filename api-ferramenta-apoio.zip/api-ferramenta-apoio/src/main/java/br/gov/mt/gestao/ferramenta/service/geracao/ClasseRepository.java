package br.gov.mt.gestao.ferramenta.service.geracao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import br.gov.mt.gestao.ferramenta.vo.Entidade;

public class ClasseRepository {

	public static final String TABULACAO = "\t";
	
	private String codigoPacote(Entidade entidade) {
		return "package " + entidade.getPacoteCompleto() + ".repository;";
	}
	
	private String codigoImportLib(Entidade entidade){
		List<String> importLib = new ArrayList<String>();
		// Adicona os imports basicos da entidade 
		importLib.add("import org.springframework.data.jpa.repository.JpaRepository;");
		importLib.add("import org.springframework.stereotype.Repository;");
		importLib.add("import " + entidade.getPacoteCompleto() + ".model." + entidade.getNomeClasse() + ";");
		// Adiciona os libs restantes
		//importLib.addAll(entidade.getImportLib().values());
		// Retorna o Código Restante
		return StringUtils.arrayToDelimitedString(importLib.toArray(), "\n");
	}
	
	private String codigoCorpoRepositoruy(Entidade entidade) {
		List<String> codigoIni = new ArrayList<String>();
		codigoIni.add("@Repository");
		codigoIni.add("public interface " + entidade.getNomeClasse() + 
				"Repository extends JpaRepository<"+ entidade.getNomeClasse() +", Long>{ ");
		codigoIni.add(TABULACAO);
		codigoIni.add("} ");
		// retorna o códoigo inicial da classe
		return StringUtils.arrayToDelimitedString(codigoIni.toArray(), "\n"); 
	}
	
	public String gerarCodigoRepository(Entidade entidade) {
		// Gera o código do Repository da entidade
		return codigoPacote(entidade) + "\n\n" +
	           codigoImportLib(entidade) + "\n\n" + 
			   codigoCorpoRepositoruy(entidade);
	}
}
