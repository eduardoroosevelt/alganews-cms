package br.gov.mt.gestao.ferramenta.service.geracao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import br.gov.mt.gestao.ferramenta.vo.Entidade;

@Component
public class EntidadeClasse {

	public static final String TABULACAO = "\t";
	
	public String codigoPacote(Entidade entidade) {
		return "package " + entidade.getPacoteCompleto() + ".model;";
	}
	
	public String codigoImportLib(Entidade entidade){
		List<String> importLib = new ArrayList<String>();
		// Adicona os imports basicos da entidade 
		importLib.add("import java.io.Serializable;");
		importLib.add("import javax.persistence.Entity;");
		importLib.add("import javax.persistence.Table;");
		importLib.add("import javax.persistence.Column;");
		importLib.add("import javax.persistence.GeneratedValue;");
	    importLib.add("import javax.persistence.GenerationType;");
		importLib.add("import javax.persistence.Id;");
		// Adiciona os libs restantes
		importLib.addAll(entidade.getImportLib().values());
		// Retorna o Código Restante
		return StringUtils.arrayToDelimitedString(importLib.toArray(), "\n");
	}
	
	public String codigoInicioClasse(Entidade entidade) {
		List<String> codigoIni = new ArrayList<String>();
		codigoIni.add("@Entity");
		codigoIni.add("@Table(name = \"" + entidade.getNomeSchema() + "." +entidade.getNomeTabela() + "\") ");
		codigoIni.add("public class " + entidade.getNomeClasse() + " implements Serializable{ ");
		codigoIni.add(TABULACAO);
		codigoIni.add(TABULACAO + "private static final long serialVersionUID = 1L;");
		// retorna o códoigo inicial da classe
		return StringUtils.arrayToDelimitedString(codigoIni.toArray(), "\n"); 
	}
	
	public String codigoFimClasse() {
		return "} ";
	}
}
